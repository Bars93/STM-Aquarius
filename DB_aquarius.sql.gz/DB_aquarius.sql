-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Время создания: Янв 10 2014 г., 13:48
-- Версия сервера: 5.5.32
-- Версия PHP: 5.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `aquarius`
--
CREATE DATABASE IF NOT EXISTS `aquarius` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `aquarius`;

-- --------------------------------------------------------

--
-- Структура таблицы `tasks`
--

CREATE TABLE IF NOT EXISTS `tasks` (
  `task_id` int(11) NOT NULL AUTO_INCREMENT,
  `task_name` text COLLATE utf8_unicode_ci NOT NULL,
  `author_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `priority` smallint(1) NOT NULL DEFAULT '4',
  `create_time` datetime NOT NULL,
  `last_edit` datetime NOT NULL,
  `last_editor` int(11) NOT NULL,
  `start_time` date NOT NULL,
  `end_time` date NOT NULL,
  `stop_time` date DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `edit_by_user` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`task_id`),
  FULLTEXT KEY `task_name` (`task_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=16 ;

--
-- Дамп данных таблицы `tasks`
--

INSERT INTO `tasks` (`task_id`, `task_name`, `author_id`, `user_id`, `priority`, `create_time`, `last_edit`, `last_editor`, `start_time`, `end_time`, `stop_time`, `comment`, `edit_by_user`) VALUES
(1, 'Строительство', 1, 1, 1, '2013-12-24 00:45:04', '2014-01-10 19:44:11', 1, '2013-12-24', '2014-01-03', '0000-00-00', 'xsdvax', 1),
(2, 'Aqua', 2, 1, 4, '2013-12-24 00:45:49', '2013-12-26 02:10:54', 1, '2013-12-24', '2020-12-24', '2013-12-26', 'steave', 1),
(8, 'Sheild', 1, 2, 4, '2013-12-24 15:02:20', '0000-00-00 00:00:00', 0, '2013-12-09', '2013-12-31', '0000-00-00', '-', 0),
(9, 'Irbis', 1, 3, 4, '2013-12-24 15:18:21', '0000-00-00 00:00:00', 0, '2013-12-09', '2013-12-31', '0000-00-00', '-', 0),
(10, 'Triangle', 1, 2, 4, '2013-12-24 15:23:46', '0000-00-00 00:00:00', 0, '2013-11-26', '2014-01-25', '0000-00-00', 'Street', 0),
(11, 'Nimbra', 1, 3, 4, '2013-12-24 15:24:11', '0000-00-00 00:00:00', 0, '2013-12-10', '2014-02-19', '0000-00-00', '-', 0),
(4, 'irbis', 1, 1, 4, '2013-12-24 10:49:35', '2013-12-26 18:40:20', 1, '2013-12-29', '2014-01-30', '0000-00-00', 'Date mod', 1),
(5, 'irbis', 1, 2, 4, '2013-12-24 11:08:17', '2013-12-26 01:35:43', 1, '2013-12-02', '2013-12-31', '2013-12-26', 'Commentaries', 1),
(13, 'Проект', 2, 2, 4, '2013-12-24 20:43:00', '0000-00-00 00:00:00', 0, '2013-12-24', '2014-02-06', '0000-00-00', 'Бизнесплан', 0),
(7, 'Latepfd34343', 3, 1, 4, '2013-12-24 12:58:09', '2013-12-26 04:11:17', 1, '2013-12-04', '2013-12-30', '2013-12-26', 'avcx', 0),
(12, 'Lim', 1, 1, 2, '2013-12-24 15:26:29', '2013-12-26 00:43:52', 1, '2013-12-09', '2013-12-30', '0000-00-00', '-`', 1),
(14, 'Carib', 1, 2, 3, '2013-12-25 02:33:56', '2013-12-26 00:40:03', 1, '2013-12-30', '2013-12-31', NULL, 'smith', 1),
(15, 'Divizion by zero', 1, 2, 5, '2013-12-26 00:53:50', '2013-12-26 02:13:15', 1, '2013-12-02', '2013-12-31', '2013-12-26', 'Season', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` char(26) COLLATE utf8_unicode_ci NOT NULL,
  `user_full_name` text COLLATE utf8_unicode_ci NOT NULL,
  `password` text COLLATE utf8_unicode_ci NOT NULL,
  `email` text COLLATE utf8_unicode_ci NOT NULL,
  `regdate` datetime NOT NULL,
  `img_path` text COLLATE utf8_unicode_ci,
  `rows_per_page` smallint(6) NOT NULL DEFAULT '5',
  PRIMARY KEY (`user_id`),
  FULLTEXT KEY `user_full_name` (`user_full_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `user_full_name`, `password`, `email`, `regdate`, `img_path`, `rows_per_page`) VALUES
(1, 'irbis', 'Popov Daniel', '18ab0ac963e6bca930d2c4daebd4b711', 'dan93irbis@mail.ru', '2013-12-16 17:53:40', 'img/default.png', 10),
(2, 'Julia', '', '18ab0ac963e6bca930d2c4daebd4b711', 'dan@bars.ru', '2013-12-16 19:48:32', 'img/default.png', 5),
(3, 'Chupakabra', '', '18ab0ac963e6bca930d2c4daebd4b711', 'bars93@mail', '2013-12-17 07:55:44', 'img/default.png', 5),
(4, 'vasia', '', '4b874169ed6ba8c4dc3eab692b8b01a7', 'vasia@void.null', '2013-12-24 11:50:26', 'img/default.png', 5);

-- --------------------------------------------------------

--
-- Структура таблицы `visit`
--

CREATE TABLE IF NOT EXISTS `visit` (
  `page_id` int(11) NOT NULL AUTO_INCREMENT,
  `page_file` text COLLATE utf8_unicode_ci NOT NULL,
  `last_visit` datetime NOT NULL,
  `v_count` int(11) NOT NULL,
  PRIMARY KEY (`page_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
